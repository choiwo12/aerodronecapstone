"""
드론 → 로버 통신: "라바콘이 로버 기준 어디에 있는지" 를 계속 보냄

  왜 '상대 위치' 인가
    드론의 위치(VO)는 비행할수록 오차가 쌓임. 하지만 라바콘과 로버를 같은 순간·같은 방식으로 재므로
    둘의 차이(라바콘 − 로버)에서는 그 오차가 상쇄됨 → 로버에게는 이 차이만 보냄.
    로버는 '메시지가 측정된 순간의 자기 위치(자체 오도메트리)' 에 이 벡터를 더해 목표점을 만들고,
    드론이 새 값을 보낼 때마다 목표점을 고침 → 로버 오도메트리 오차도 도착할수록 줄어듦.

  메시지 (UDP, JSON 한 줄, 기본 5 Hz)
    {"type": "cone_goal", "seq": 12,
     "age": 0.31,                 # 측정(짐벌 촬영) 순간부터 보낸 순간까지 [s] → 로버는 (받은 시각 − age) 의 자기 위치를 씀
     "rel_n": 12.4, "rel_e": -3.1,# 로버 → 라바콘 벡터, 북/동 [m] (드론 FC 의 나침반 기준 방향)
     "dist": 12.78,               # 라바콘–로버 거리 [m]
     "same_instant": true,        # true = 같은 순간 로버도 봄 (정확), false = 로버 위치를 예측으로 계산 (덜 정확)
     "n_cone": 40}                # 라바콘 위치 평균에 쓴 측정 개수 (많을수록 안정)

  로버 쪽 주의: rel_n/rel_e 는 '북/동' 방향. 로버 오도메트리 좌표가 북쪽 정렬이 아니면 로버 나침반(IMU) yaw 로 돌려서 쓸 것.

  드론 쪽 사용:  link = RoverLink("192.168.0.20", 47000);  link.send(result, worker.cone_world())
  로버 쪽 예시:  RoverGoalReceiver (아래) — 경로 생성 팀은 goal() 이 주는 목표점만 받아 쓰면 됨
"""
import json
import socket
import threading
import time
from collections import deque

import numpy as np


class RoverLink:
    def __init__(self, host, port=47000, rate_hz=5.0):
        self.addr = (host, int(port))
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.min_dt = 1.0 / rate_hz
        self.seq, self.t_last, self.n_sent = 0, 0.0, 0
        self.enabled = True                      # 메인 루프가 OFFBOARD 일 때만 켬 (드론이 로버 위에 없으면 보내지 않음)

    def send(self, res, cone_w=None, n_cone=0):
        """res: TargetWorker 결과 dict. cone_w: 기억한 라바콘 위치(여러 측정의 중앙값) — 있으면 이걸 씀"""
        now = time.time()
        if not self.enabled or res is None or res.get("rover_w") is None or now - self.t_last < self.min_dt:
            return False
        # 로버를 '같은 순간' 본 측정만 보냄. 예측 로버 위치는 로버가 가려진 채 꺾으면 수 m~십수 m 틀림 (SITL 우회 시험)
        # → 로버 자신의 오도메트리가 훨씬 정확하므로, 이때는 아무것도 안 보내고 로버가 마지막 목표점을 유지하게 함
        if res.get("rover_src") != "동시관측":
            return False
        cone = np.asarray(cone_w if cone_w is not None else res["target_w"], float)
        rel = cone - np.asarray(res["rover_w"], float)
        msg = {"type": "cone_goal", "seq": self.seq, "age": round(now - res["t"], 3),
               "rel_n": round(float(rel[0]), 3), "rel_e": round(float(rel[1]), 3),
               "dist": round(float(np.hypot(*rel)), 3),
               "same_instant": res.get("rover_src") == "동시관측", "n_cone": int(n_cone)}
        self.sock.sendto(json.dumps(msg).encode(), self.addr)
        self.seq += 1; self.t_last = now; self.n_sent += 1
        return True


class RoverGoalReceiver(threading.Thread):
    """
    로버 쪽 참고 구현. 로버 오도메트리를 add_odom() 으로 계속 넣어 주면 goal() 이 목표점(오도메트리 좌표)을 줌
      rx = RoverGoalReceiver(47000); rx.start()
      매 주기: rx.add_odom(time.time(), (x_north, y_east))
               g = rx.goal()   → None 이면 아직 라바콘 모름, 아니면 (x, y) 로 경로 생성
    """

    def __init__(self, port=47000, use_predicted_after=None, smooth_s=3.0):
        super().__init__(daemon=True)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("0.0.0.0", int(port)))
        self.sock.settimeout(0.2)
        self.odom = deque(maxlen=400)             # (시각, x, y)
        self.lock = threading.Lock()
        self._goal, self.last_msg, self.t_last_same, self.n_rx = None, None, 0.0, 0
        self.use_predicted_after = use_predicted_after
        self.smooth_s = smooth_s                  # 최근 이 시간 동안의 목표점들의 중앙값을 씀 (측정 하나하나의 흔들림 제거)
        self._goals = deque(maxlen=200)           # (받은 시각, x, y)
        self.stop_flag = False

    def add_odom(self, t, xy):
        with self.lock:
            self.odom.append((t, float(xy[0]), float(xy[1])))

    def _odom_at(self, t):
        if not self.odom:
            return None
        o = np.array(self.odom)
        i = int(np.argmin(np.abs(o[:, 0] - t)))
        return o[i, 1:]

    def run(self):
        while not self.stop_flag:
            try:
                data, _ = self.sock.recvfrom(4096)
            except socket.timeout:
                continue
            t_rx = time.time()
            try:
                m = json.loads(data.decode())
            except ValueError:
                continue
            if m.get("type") != "cone_goal":
                continue
            # 로버를 같은 순간 본 값만 사용 (예측값은 무시 — use_predicted_after 초를 주면 그만큼 같은 순간 값이 없을 때만 예측값도 사용)
            if not m["same_instant"] and (self.use_predicted_after is None or t_rx - self.t_last_same < self.use_predicted_after):
                continue
            with self.lock:
                p = self._odom_at(t_rx - m["age"])
                if p is None:
                    continue
                g = p + np.array([m["rel_n"], m["rel_e"]])
                self._goals.append((t_rx, g[0], g[1]))
                rec = np.array([q[1:] for q in self._goals if t_rx - q[0] <= self.smooth_s])
                self._goal = np.median(rec, axis=0)
                self.last_msg = m; self.n_rx += 1
                if m["same_instant"]:
                    self.t_last_same = t_rx

    def goal(self):
        with self.lock:
            return None if self._goal is None else self._goal.copy()

    def stop(self):
        self.stop_flag = True


# ------------------------------------------------------------------ 로버 → 드론: 로버 오도메트리
#  로버가 캐노피 밑 등에서 가려지면 드론은 로버 위치를 모름. 직진 예측은 로버가 가려진 채 꺾으면 10 m 넘게 틀림 (SITL 우회 시험)
#  → 로버가 자기 오도메트리(바퀴·IMU, 북/동 정렬)를 계속 보내 주면, 드론은
#     '마지막으로 본 로버 위치 + (지금 오도메트리 − 그때 오도메트리)' 로 가려진 로버 위치를 앎
#  메시지 (UDP, JSON): {"type": "rover_odom", "seq": 3, "n": 12.31, "e": -4.02, "arrived": false}
#    (로버 오도메트리 좌표 [m], 10~20 Hz. arrived = 라바콘 옆 도착 → 드론 --auto 착륙 신호)


class RoverOdomSender:
    """로버 쪽: odom = (북, 동) [m] 을 주기적으로 드론에 보냄"""

    def __init__(self, host, port=47002):
        self.addr = (host, int(port)); self.seq = 0
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def send(self, xy, arrived=False):
        # ts = 로버 시계 [s]: 드론 비행 기록(flight.csv rover_ts)과 로버 mission.jsonl 시각을 맞추는 데 씀
        self.sock.sendto(json.dumps({"type": "rover_odom", "seq": self.seq,
                                     "n": round(float(xy[0]), 3), "e": round(float(xy[1]), 3),
                                     "arrived": bool(arrived), "ts": round(time.time(), 3)}).encode(), self.addr)
        self.seq += 1


class RoverOdomListener(threading.Thread):
    """드론 쪽: 로버 오도메트리 수신. at(t) = 그 시각(드론 시계, 받은 시각 기준)의 로버 오도메트리"""

    def __init__(self, port=47002, max_age=0.5):
        super().__init__(daemon=True)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("0.0.0.0", int(port))); self.sock.settimeout(0.2)
        self.buf = deque(maxlen=2000)             # (받은 시각, 북, 동)
        self.lock = threading.Lock(); self.stop_flag = False; self.max_age = max_age
        self._arrived = False
        self.rover_ts = None                      # 마지막 메시지의 로버 시계 (없으면 None — 예전 형식)

    def run(self):
        while not self.stop_flag:
            try:
                data, _ = self.sock.recvfrom(1024)
                m = json.loads(data.decode())
            except (socket.timeout, ValueError):
                continue
            if m.get("type") == "rover_odom":
                with self.lock:
                    self.buf.append((time.time(), m["n"], m["e"]))
                    self._arrived = bool(m.get("arrived", False))
                    self.rover_ts = m.get("ts")

    def fresh(self):
        with self.lock:
            return bool(self.buf) and time.time() - self.buf[-1][0] < self.max_age

    def arrived(self):
        """로버가 지금 '도착' 을 보내는 중인지 (메시지가 끊기면 False)"""
        return self.fresh() and self._arrived

    def latest(self):
        with self.lock:
            return None if not self.buf else np.array(self.buf[-1][1:])

    def at(self, t):
        with self.lock:
            if not self.buf:
                return None
            o = np.array(self.buf)
        i = int(np.argmin(np.abs(o[:, 0] - t)))
        return None if abs(o[i, 0] - t) > 0.5 else o[i, 1:]

    def stop(self):
        self.stop_flag = True
