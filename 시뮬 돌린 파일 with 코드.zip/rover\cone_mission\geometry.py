"""Frames and the stop point beside the cone.

Frames
  NE   : north/east [m], what the drone sends (rover_link cone_goal rel_n/rel_e).
  odom : the rover's odometry frame (x, y, yaw). Its +x is rotated `north_yaw` rad (CCW)
         away from north, i.e. north = (cos a, sin a) in odom.
         Gazebo world with x=east, y=north and the rover spawned at yaw 0  ->  north_yaw = pi/2.
         Real rover: measure the compass heading of odom +x at start-up.
"""
import math

import numpy as np

CONE_RADIUS = 0.19        # cone base radius [m]
ROVER_HALF_WIDTH = 0.21   # 3MAX-V3 half width [m]
SIDE_GAP = 0.30           # required free gap between cone base edge and rover side [m]
STANDOFF = CONE_RADIUS + ROVER_HALF_WIDTH + SIDE_GAP   # cone centre -> rover centre = 0.70 m


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


class Frames:
    def __init__(self, north_yaw):
        a = float(north_yaw)
        self.u_n = np.array([math.cos(a), math.sin(a)])
        self.u_e = np.array([math.sin(a), -math.cos(a)])   # east = north turned 90 deg clockwise

    def ne_to_odom(self, ne):
        return float(ne[0]) * self.u_n + float(ne[1]) * self.u_e

    def odom_to_ne(self, xy):
        v = np.asarray(xy, float)
        return np.array([v @ self.u_n, v @ self.u_e])


def to_rover_frame(pose, xy):
    """odom point -> (forward, left) relative to rover pose (x, y, yaw); this is /goal_relative."""
    x, y, yaw = pose
    dx, dy = xy[0] - x, xy[1] - y
    c, s = math.cos(yaw), math.sin(yaw)
    return c * dx + s * dy, -s * dx + c * dy


def stop_point(cone, heading, standoff=STANDOFF):
    """Rover centre when parked heading `heading` with the cone on its right side."""
    left = np.array([-math.sin(heading), math.cos(heading)])
    return np.asarray(cone, float) + standoff * left


def approach(cone, rover_xy, lead=2.0, standoff=STANDOFF, free=lambda p, s: True):
    """Pick (pre_point, stop_point, heading).

    Preferred heading: straight from the rover towards the cone. If the stop point or the
    straight lead-in is blocked, try headings rotated by +-30, +-60 ... deg.
    """
    d = np.asarray(cone, float) - np.asarray(rover_xy, float)
    base = math.atan2(d[1], d[0])
    for k in (0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6):
        h = wrap(base + k * math.radians(30))
        s = stop_point(cone, h, standoff)
        p = s - lead * np.array([math.cos(h), math.sin(h)])
        if free(p, s):
            return p, s, h
    h = base
    s = stop_point(cone, h, standoff)
    return s - lead * np.array([math.cos(h), math.sin(h)]), s, h


LIDAR_X = 0.28            # RPLIDAR C1 at the front bumper: 0.28 m ahead of the rover centre


def lidar_pose(pose, lidar_x=LIDAR_X):
    """rover pose (x, y, yaw) -> lidar pose (lidar on the rover's centre line, lidar_x ahead)"""
    x, y, yaw = pose
    return x + lidar_x * math.cos(yaw), y + lidar_x * math.sin(yaw), yaw


def self_filter(angle_min, angle_inc, ranges, deg=95.0, max_r=0.6):
    """Drop returns from the rover's own body: |angle| >= deg and closer than max_r (front-mounted lidar sees the
    body behind it). Same rule as rover_navigation self_filter_deg / self_filter_range."""
    lim = math.radians(deg)
    out = list(ranges)
    for i, r in enumerate(out):
        a = (angle_min + i * angle_inc + math.pi) % (2 * math.pi) - math.pi
        if abs(a) >= lim and math.isfinite(r) and r < max_r:
            out[i] = float("nan")
    return out


def scan_points(pose, angle_min, angle_inc, ranges, range_max, max_range=6.0):
    """Lidar hits -> odom-frame points (N, 2)."""
    x, y, yaw = pose
    r = np.asarray(ranges, float)
    a = yaw + angle_min + angle_inc * np.arange(len(r))
    ok = np.isfinite(r) & (r < min(range_max, max_range)) & (r > 0.1)
    return np.stack([x + r[ok] * np.cos(a[ok]), y + r[ok] * np.sin(a[ok])], axis=1)


def refine_cone(cone, pts, rover_xy, gate=1.2, max_extent=0.45, r_lidar=0.16, min_pts=3):
    """Snap the drone's cone estimate to the rover-lidar cluster around it.

    Takes lidar points within `gate` of the estimate; rejects the cluster if it is wider than a
    cone (`max_extent`, e.g. the estimate sits next to a wall). The visible arc's mean lies
    ~pi/4*r in front of the centre, so push it away from the rover by that much.
    Returns (cone_xy, True) or (cone, False)."""
    cone = np.asarray(cone, float)
    if pts is None or len(pts) == 0:
        return cone, False
    near = pts[np.hypot(*(pts - cone).T) < gate]
    if len(near) < min_pts:
        return cone, False
    m = near.mean(axis=0)
    if np.max(np.hypot(*(near - m).T)) > max_extent / 2:
        return cone, False
    u = m - np.asarray(rover_xy, float)
    u /= np.linalg.norm(u) + 1e-9
    return m + (math.pi / 4) * r_lidar * u, True


def side_gap(rover_pose, cone):
    """Free gap between cone base edge and the rover's right side, plus how far along the cone is.
    Returns (gap [m], along [m]): along>0 means cone is ahead of rover centre."""
    fwd, left = to_rover_frame(rover_pose, cone)
    return -left - CONE_RADIUS - ROVER_HALF_WIDTH, fwd
