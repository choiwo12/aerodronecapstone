"""Obstacle memory from lidar + RRT* (rover/rrt_star.py, unchanged) wrapper."""
import math
import os
import random
import sys
from collections import defaultdict

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rrt_star import RRTStar  # noqa: E402

INFLATE = 0.45     # rover treated as a point: obstacles grow by half its width (0.21) + margin [m].
                   # 0.30 let paths pass 0.38 m from a post, inside rover_navigation's front stop cone (+-17 deg, 1.2 m)
                   # -> repeated BLOCKED_STOP in front of canopy posts (Gazebo, Mask R-CNN run2)


class ObstacleMap:
    """Accumulates lidar hits (odom frame) in a voxel set and summarises them as circles."""

    def __init__(self, voxel=0.2, cell=1.0, max_range=8.0, min_hits=2):
        self.voxel, self.cell, self.max_range, self.min_hits = voxel, cell, max_range, min_hits
        self.hits = defaultdict(int)

    def add_scan(self, pose, angle_min, angle_inc, ranges, range_max):
        x, y, yaw = pose
        for i, r in enumerate(ranges):
            if not math.isfinite(r) or r >= min(range_max, self.max_range) or r < 0.1:
                continue
            a = yaw + angle_min + i * angle_inc
            k = (int(math.floor((x + r * math.cos(a)) / self.voxel)),
                 int(math.floor((y + r * math.sin(a)) / self.voxel)))
            self.hits[k] += 1

    def points(self):
        v = self.voxel
        return np.array([((k[0] + 0.5) * v, (k[1] + 0.5) * v) for k, n in self.hits.items()
                         if n >= self.min_hits]).reshape(-1, 2)

    def circles(self, inflate=INFLATE):
        pts = self.points()
        groups = defaultdict(list)
        for p in pts:
            groups[(int(math.floor(p[0] / self.cell)), int(math.floor(p[1] / self.cell)))].append(p)
        out = []
        for g in groups.values():
            g = np.array(g)
            c = g.mean(axis=0)
            r = float(np.max(np.hypot(*(g - c).T))) + self.voxel / 2 + inflate
            out.append((float(c[0]), float(c[1]), r))
        return out


class FastRRTStar(RRTStar):
    """rrt_star.RRTStar with numpy versions of its three hot loops; plan() and the algorithm
    itself are inherited unchanged. Same results as the parent for the same random sequence."""

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        ob = np.array(self.obstacles, float).reshape(-1, 3)
        self._ox, self._oy, self._or = ob[:, 0], ob[:, 1], ob[:, 2]
        self._xy = np.empty((0, 2))

    def _sync(self):
        n = len(self._xy)
        if n < len(self.nodes):
            self._xy = np.vstack([self._xy, [(q.x, q.y) for q in self.nodes[n:]]])

    def nearest_node(self, random_node):
        self._sync()
        d = np.hypot(self._xy[:, 0] - random_node.x, self._xy[:, 1] - random_node.y)
        return self.nodes[int(np.argmin(d))]

    def find_near_nodes(self, new_node):
        self._sync()
        d = np.hypot(self._xy[:, 0] - new_node.x, self._xy[:, 1] - new_node.y)
        return [self.nodes[i] for i in np.nonzero(d <= self.search_radius)[0]]

    def collision_free(self, node1, node2):
        if not len(self._or):
            return True
        dx, dy = node2.x - node1.x, node2.y - node1.y
        steps = max(int(math.hypot(dx, dy) / 0.05), 1)
        t = np.arange(steps + 1) / steps
        px, py = node1.x + t * dx, node1.y + t * dy
        d = np.hypot(px[:, None] - self._ox[None, :], py[:, None] - self._oy[None, :])
        return not np.any(d <= self._or[None, :])


def inside(p, circles, margin=0.0):
    return any(math.hypot(p[0] - ox, p[1] - oy) <= r + margin for ox, oy, r in circles)


def segment_free(a, b, circles):
    return FastRRTStar(tuple(a), tuple(b), circles).collision_free(_N(*a), _N(*b))


class _N:
    def __init__(self, x, y):
        self.x, self.y = float(x), float(y)


def shortcut(path, circles):
    out, i = [path[0]], 0
    while i < len(path) - 1:
        j = len(path) - 1
        while j > i + 1 and not segment_free(path[i], path[j], circles):
            j -= 1
        out.append(path[j]); i = j
    return out


def plan(start, goal, circles, seed=0, margins=(4.0, 8.0, 12.0), max_iter=2000):
    """RRT* from start to goal. Obstacles that swallow the start are dropped (we are already
    there; rover_navigation's lidar stop keeps us safe). The sampling box is start/goal +- margin;
    it grows on each retry so a detour around a long wall fits. Returns list of (x, y) or None."""
    obs = [c for c in circles if not inside(start, [c])]
    if inside(goal, obs):
        return None
    if segment_free(start, goal, obs):
        return [tuple(map(float, start)), tuple(map(float, goal))]
    xs, ys = (start[0], goal[0]), (start[1], goal[1])
    for k, margin in enumerate(margins):
        random.seed(seed + k)
        rrt = FastRRTStar(tuple(map(float, start)), tuple(map(float, goal)), obs,
                          x_range=(min(xs) - margin, max(xs) + margin),
                          y_range=(min(ys) - margin, max(ys) + margin),
                          step_size=0.5, max_iter=max_iter, search_radius=2.0)
        path = rrt.plan()
        if path:
            return shortcut(path, obs)
    return None
