"""ROS 2 node on the rover Jetson: drone cone position -> RRT* path -> /goal_relative for rover_navigation.py

  UDP in  47000  cone_goal from the drone (rover_link.RoverGoalReceiver, unchanged)
  UDP out 47002  rover_odom to the drone, 20 Hz (rover_link.RoverOdomSender; arrived = state ARRIVED -> drone --auto lands)
  ROS in  /odom, /scan
  ROS out /goal_relative (geometry_msgs/Point), /mission/path (nav_msgs/Path), /mission/state (std_msgs/String)
  Sets rover_navigation parameters (side_clearance, clearance, stop_distance, arrival_radius)
  for the final approach and back.

Parameters
  north_yaw   angle of north in the odom frame [rad, CCW from odom +x]. Gazebo cone_field: pi/2.
  drone_host  where to send rover_odom (drone Jetson IP)

  python3 cone_mission_node.py --ros-args -p north_yaw:=1.5708 -p drone_host:=127.0.0.1
"""
import json
import math
import os
import sys
import time

import rclpy
from geometry_msgs.msg import Point, PoseStamped
from nav_msgs.msg import Odometry, Path
from rcl_interfaces.msg import Parameter as ParamMsg, ParameterType, ParameterValue
from rcl_interfaces.srv import SetParameters
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))                                   # rover/
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(HERE)), "drone"))
from cone_mission import ConeMission, Frames, ObstacleMap, NORMAL, LIDAR_X, lidar_pose, scan_points, self_filter  # noqa: E402
from rover_link import RoverGoalReceiver, RoverOdomSender  # noqa: E402


class ConeMissionNode(Node):
    def __init__(self):
        super().__init__("cone_mission")
        self.declare_parameter("north_yaw", math.pi / 2)
        self.declare_parameter("goal_port", 47000)
        self.declare_parameter("drone_host", "127.0.0.1")
        self.declare_parameter("odom_port", 47002)
        self.declare_parameter("nav_node", "rover_navigation")
        self.declare_parameter("log_file", "")
        self.declare_parameter("lidar_x", LIDAR_X)          # lidar ahead of the rover centre [m] (front bumper)
        p = lambda n: self.get_parameter(n).value  # noqa: E731
        self.frames = Frames(float(p("north_yaw")))
        self.rx = RoverGoalReceiver(int(p("goal_port")))
        self.rx.start()
        self.tx = RoverOdomSender(p("drone_host"), int(p("odom_port")))
        self.mission, self.omap = ConeMission(), ObstacleMap()
        self.pose, self.scan_pts = None, None
        self.create_subscription(Odometry, "/odom", self.on_odom, 10)
        self.create_subscription(LaserScan, "/scan", self.on_scan, 10)
        self.pub_goal = self.create_publisher(Point, "/goal_relative", 10)
        self.pub_path = self.create_publisher(Path, "/mission/path", 1)
        self.pub_state = self.create_publisher(String, "/mission/state", 1)
        self.param_cli = self.create_client(SetParameters, "/%s/set_parameters" % p("nav_node"))
        self.log = open(p("log_file"), "w") if p("log_file") else None
        self.pending_params = dict(NORMAL)
        self.create_timer(0.05, self.send_odom)
        self.create_timer(0.1, self.tick)
        self.get_logger().info("cone_mission ready: waiting for cone_goal on UDP %d" % p("goal_port"))

    def on_odom(self, m):
        q = m.pose.pose.orientation
        yaw = math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))
        self.pose = (m.pose.pose.position.x, m.pose.pose.position.y, yaw)
        self.rx.add_odom(time.time(), self.frames.odom_to_ne(self.pose[:2]))

    def on_scan(self, m):
        if self.pose is not None:
            ranges = self_filter(m.angle_min, m.angle_increment, m.ranges)
            lp = lidar_pose(self.pose, float(self.get_parameter("lidar_x").value))
            self.omap.add_scan(lp, m.angle_min, m.angle_increment, ranges, m.range_max)
            self.scan_pts = scan_points(lp, m.angle_min, m.angle_increment, ranges, m.range_max)

    def send_odom(self):
        if self.pose is not None:
            self.tx.send(self.frames.odom_to_ne(self.pose[:2]), self.mission.state == "ARRIVED")

    def set_nav_params(self, values):
        if not self.param_cli.service_is_ready():
            self.pending_params = dict(values)
            return
        req = SetParameters.Request()
        for k, v in values.items():
            req.parameters.append(ParamMsg(name=k, value=ParameterValue(
                type=ParameterType.PARAMETER_DOUBLE, double_value=float(v))))
        self.param_cli.call_async(req)
        self.pending_params = None

    def tick(self):
        if self.pose is None:
            return
        if self.pending_params and self.param_cli.service_is_ready():
            self.set_nav_params(self.pending_params)
        g = self.rx.goal()
        cone = None if g is None else self.frames.ne_to_odom(g)
        before = self.mission.state
        for kind, val in self.mission.step(time.time(), self.pose, cone, self.omap.circles(), self.scan_pts):
            if kind == "goal":
                self.pub_goal.publish(Point(x=float(val[0]), y=float(val[1]), z=0.0))
                self.publish_path()
            else:
                self.set_nav_params(val)
        if self.mission.state != before:
            self.get_logger().info("state %s -> %s" % (before, self.mission.state))
        self.pub_state.publish(String(data=self.mission.state))
        if self.log:
            self.log.write(json.dumps({
                "t": time.time(), "pose": list(self.pose), "state": self.mission.state,
                "cone": None if cone is None else [float(cone[0]), float(cone[1])],
                "cone_used": None if self.mission.cone_used is None else list(map(float, self.mission.cone_used)),
                "lidar_lock": bool(self.mission.lidar_lock),
                "wps": [list(map(float, w)) for w in self.mission.waypoints],
                "idx": self.mission.idx}) + "\n")
            self.log.flush()

    def publish_path(self):
        msg = Path()
        msg.header.frame_id = "odom"
        for x, y in [self.pose[:2]] + list(self.mission.waypoints[self.mission.idx:]):
            ps = PoseStamped()
            ps.header.frame_id = "odom"
            ps.pose.position.x, ps.pose.position.y = float(x), float(y)
            msg.poses.append(ps)
        self.pub_path.publish(msg)


def main():
    rclpy.init()
    node = ConeMissionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.rx.stop()
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
