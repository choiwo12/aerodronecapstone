import math
import random


class Node:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.parent = None
        self.cost = 0.0


class RRTStar:
    def __init__(
        self,
        start,
        goal,
        obstacles,
        x_range=(-10, 10),
        y_range=(0, 20),
        step_size=0.5,
        goal_sample_rate=0.1,
        max_iter=3000,
        search_radius=2.0
    ):
        self.start = Node(*start)
        self.goal = Node(*goal)
        self.obstacles = obstacles
        self.x_range = x_range
        self.y_range = y_range
        self.step_size = step_size
        self.goal_sample_rate = goal_sample_rate
        self.max_iter = max_iter
        self.search_radius = search_radius
        self.nodes = [self.start]

    def distance(self, n1, n2):
        return math.hypot(n2.x - n1.x, n2.y - n1.y)

    def sample(self):
        if random.random() < self.goal_sample_rate:
            return Node(self.goal.x, self.goal.y)

        x = random.uniform(*self.x_range)
        y = random.uniform(*self.y_range)
        return Node(x, y)

    def nearest_node(self, random_node):
        return min(
            self.nodes,
            key=lambda node: self.distance(node, random_node)
        )

    def steer(self, from_node, to_node):
        dx = to_node.x - from_node.x
        dy = to_node.y - from_node.y
        theta = math.atan2(dy, dx)

        dist = min(
            self.step_size,
            self.distance(from_node, to_node)
        )

        return Node(
            from_node.x + dist * math.cos(theta),
            from_node.y + dist * math.sin(theta)
        )

    def collision_free(self, node1, node2):
        dx = node2.x - node1.x
        dy = node2.y - node1.y
        distance = math.hypot(dx, dy)

        steps = max(int(distance / 0.05), 1)

        for i in range(steps + 1):
            t = i / steps
            x = node1.x + t * dx
            y = node1.y + t * dy

            for ox, oy, radius in self.obstacles:
                if math.hypot(x - ox, y - oy) <= radius:
                    return False

        return True

    def find_near_nodes(self, new_node):
        return [
            node for node in self.nodes
            if self.distance(node, new_node) <= self.search_radius
        ]

    def choose_parent(self, new_node, near_nodes):
        best_parent = None
        min_cost = float("inf")

        for node in near_nodes:
            if not self.collision_free(node, new_node):
                continue

            new_cost = node.cost + self.distance(node, new_node)

            if new_cost < min_cost:
                min_cost = new_cost
                best_parent = node

        if best_parent is not None:
            new_node.parent = best_parent
            new_node.cost = min_cost

        return new_node

    def rewire(self, new_node, near_nodes):
        for node in near_nodes:
            if node == new_node.parent:
                continue

            if not self.collision_free(new_node, node):
                continue

            new_cost = new_node.cost + self.distance(new_node, node)

            if new_cost < node.cost:
                node.parent = new_node
                node.cost = new_cost

    def extract_path(self, goal_node):
        path = []
        current = goal_node

        while current is not None:
            path.append((current.x, current.y))
            current = current.parent

        path.reverse()
        return path

    def plan(self):
        for _ in range(self.max_iter):
            random_node = self.sample()
            nearest = self.nearest_node(random_node)
            new_node = self.steer(nearest, random_node)

            if not self.collision_free(nearest, new_node):
                continue

            near_nodes = self.find_near_nodes(new_node)

            new_node.parent = nearest
            new_node.cost = (
                nearest.cost
                + self.distance(nearest, new_node)
            )

            new_node = self.choose_parent(
                new_node,
                near_nodes
            )

            self.nodes.append(new_node)

            self.rewire(
                new_node,
                near_nodes
            )

            if self.distance(new_node, self.goal) <= self.step_size:
                if self.collision_free(new_node, self.goal):
                    self.goal.parent = new_node
                    self.goal.cost = (
                        new_node.cost
                        + self.distance(new_node, self.goal)
                    )
                    return self.extract_path(self.goal)

        return None


if __name__ == "__main__":
    random.seed(42)

    start = (0.0, 0.0)
    goal = (3.36, 10.0)

    obstacles = [
        (0.90, 3.20, 0.95),   # person
        (2.50, 6.80, 0.85),   # cone
        (-4.58, 6.67, 0.95),  # person
        (-7.11, 7.57, 1.25),  # plant
        (8.09, 14.77, 2.0)    # car (circular approximation)
    ]

    planner = RRTStar(
        start=start,
        goal=goal,
        obstacles=obstacles,
        x_range=(-10, 10),
        y_range=(0, 20),
        step_size=0.5,
        max_iter=3000,
        search_radius=2.0
    )

    path = planner.plan()

    if path is None:
        print("경로를 찾지 못했습니다.")
    else:
        print("RRT* Path")
        for i, point in enumerate(path):
            print(f"WP{i}: {point}")
