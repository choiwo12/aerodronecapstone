"""ROS 2 Ackermann rover waypoint follower with simple 2D lidar reactive avoidance.
Topics: /odom (nav_msgs/Odometry), /scan (sensor_msgs/LaserScan),
        /goal_relative (geometry_msgs/Point, x forward/y left in rover frame),
        /cmd_vel (geometry_msgs/Twist: linear.x m/s, angular.z rad/s).
For Gazebo model with Ackermann steering, use a compatible Twist-to-Ackermann controller.
"""
import math
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Point, Twist


def norm(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def sector_min(scan, center_deg, half_width_deg=17):
    if not scan.ranges or scan.angle_increment == 0:
        return None
    values = []
    for i, distance in enumerate(scan.ranges):
        if distance == math.inf:  # no return within range: treat as free space
            distance = scan.range_max
        angle = norm(scan.angle_min + i * scan.angle_increment - math.radians(center_deg))
        if abs(angle) <= math.radians(half_width_deg) and math.isfinite(distance) and scan.range_min <= distance <= scan.range_max:
            values.append(distance)
    return min(values) if values else None


class RoverNavigation(Node):
    def __init__(self):
        super().__init__('rover_navigation')
        self.declare_parameter('wheelbase', 0.287)
        self.declare_parameter('max_speed', 0.45)
        self.declare_parameter('max_steer_deg', 25.0)
        self.declare_parameter('arrival_radius', 0.35)
        self.declare_parameter('stop_distance', 1.2)
        self.declare_parameter('clearance', 1.8)
        self.declare_parameter('side_clearance', 0.75)
        self.declare_parameter('sensor_timeout', 0.7)
        # Reverse recovery: blocked in front for blocked_wait s -> back up reverse_distance m (steering so the nose
        # swings toward the freer/goal side), only while the rear sector is clear.
        self.declare_parameter('reverse_enable', True)
        self.declare_parameter('reverse_speed', 0.2)
        self.declare_parameter('reverse_distance', 1.0)
        self.declare_parameter('rear_clearance', 0.45)
        self.declare_parameter('blocked_wait', 1.0)
        # Front-mounted lidar (RPLIDAR C1 at the front bumper): the rover body blocks the rear half.
        #  rear_check=False -> no lidar rear check; reverse only along the path just driven forward (>= reverse_distance).
        #  self_filter: readings closer than self_filter_range at |angle| >= self_filter_deg are the rover's own body.
        self.declare_parameter('rear_check', True)
        self.declare_parameter('self_filter_deg', 95.0)
        self.declare_parameter('self_filter_range', 0.6)
        self.trail = []
        self.blocked_since = None
        self.reverse_start = None
        self.reverse_steer = 0.0
        self.odom = None
        self.scan = None
        self.odom_time = None
        self.scan_time = None
        self.goal = None
        self.state = 'WAIT_GOAL'
        self.create_subscription(Odometry, '/odom', self.on_odom, 10)
        self.create_subscription(LaserScan, '/scan', self.on_scan, 10)
        self.create_subscription(Point, '/goal_relative', self.on_goal, 10)
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.create_timer(0.1, self.control)
        self.get_logger().info('Ready: send relative goal x forward, y left in meters')

    def on_odom(self, msg):
        self.odom = msg
        self.odom_time = self.get_clock().now()

    def on_scan(self, msg):
        lim, rmax = math.radians(float(self.get_parameter('self_filter_deg').value)), float(self.get_parameter('self_filter_range').value)
        r = list(msg.ranges)
        for i, d in enumerate(r):
            if abs(norm(msg.angle_min + i * msg.angle_increment)) >= lim and math.isfinite(d) and d < rmax:
                r[i] = float('nan')                          # own body, not an obstacle
        msg.ranges = r
        self.scan = msg
        self.scan_time = self.get_clock().now()

    def pose(self):
        p = self.odom.pose.pose.position
        q = self.odom.pose.pose.orientation
        yaw = math.atan2(2*(q.w*q.z + q.x*q.y), 1-2*(q.y*q.y + q.z*q.z))
        return p.x, p.y, yaw

    def on_goal(self, msg):
        if self.odom is None:
            self.get_logger().warn('No odometry; relative goal rejected')
            return
        x, y, yaw = self.pose()
        # Relative rover-frame goal is frozen as an odom-frame destination at reception.
        self.goal = (x + math.cos(yaw)*msg.x - math.sin(yaw)*msg.y,
                     y + math.sin(yaw)*msg.x + math.cos(yaw)*msg.y)
        self.state = 'TRACK'
        self.get_logger().info(f'New goal in odom frame: {self.goal}')

    def fresh(self, stamp):
        return stamp is not None and (self.get_clock().now()-stamp).nanoseconds/1e9 < float(self.get_parameter('sensor_timeout').value)

    def rear_ok(self):
        """Is it safe to back up reverse_distance?"""
        need = float(self.get_parameter('reverse_distance').value)
        if bool(self.get_parameter('rear_check').value):
            rear = sector_min(self.scan, 180)
            return rear is not None and rear >= float(self.get_parameter('rear_clearance').value)
        # rear not visible: only along the forward path just driven
        return sum(math.hypot(a[0] - b[0], a[1] - b[1]) for a, b in zip(self.trail, self.trail[1:])) >= need

    def command(self, speed, steering):
        wheelbase = float(self.get_parameter('wheelbase').value)
        # Publish body yaw rate; steering angle approximated by atan(wheelbase*omega/v).
        msg = Twist()
        msg.linear.x = float(speed)
        msg.angular.z = float(speed * math.tan(steering) / wheelbase) if speed != 0 else 0.0
        self.publisher.publish(msg)

    def control(self):
        if self.goal is None or not self.fresh(self.odom_time) or not self.fresh(self.scan_time):
            self.state = 'STOP_NO_DATA'
            self.command(0, 0)
            return
        x, y, yaw = self.pose()
        dx, dy = self.goal[0]-x, self.goal[1]-y
        distance = math.hypot(dx, dy)
        if distance < float(self.get_parameter('arrival_radius').value):
            self.state = 'ARRIVED'
            self.goal = None
            self.command(0, 0)
            self.get_logger().info('Goal reached: STOP')
            return
        left = sector_min(self.scan, 50)
        front = sector_min(self.scan, 0)
        right = sector_min(self.scan, -50)
        if front is None or left is None or right is None:
            self.state = 'STOP_SCAN_INVALID'
            self.command(0, 0)
            return
        limit = math.radians(float(self.get_parameter('max_steer_deg').value))
        desired = norm(math.atan2(dy, dx)-yaw)
        steer = max(-limit, min(limit, 1.1*desired))
        speed = min(float(self.get_parameter('max_speed').value), max(0.12, distance*0.35))
        if self.reverse_start is not None:
            moved = math.hypot(x - self.reverse_start[0], y - self.reverse_start[1])
            rear = sector_min(self.scan, 180) if bool(self.get_parameter('rear_check').value) else None
            if rear is not None and rear < float(self.get_parameter('rear_clearance').value):
                self.reverse_start = None                    # rear blocked: give up, stay stopped
                self.state = 'BLOCKED_STOP'
                self.command(0, 0)
                return
            if moved < float(self.get_parameter('reverse_distance').value):
                self.state = 'REVERSE'
                self.command(-float(self.get_parameter('reverse_speed').value), self.reverse_steer)
                return
            self.reverse_start = None
            # Only the stretch just backed over is used up; the path driven before it can still be reversed along.
            used = 0.0
            while len(self.trail) > 1 and used < moved:
                used += math.hypot(self.trail[-1][0] - self.trail[-2][0], self.trail[-1][1] - self.trail[-2][1])
                self.trail.pop()
            if used < moved:
                self.trail = []
        if front < float(self.get_parameter('stop_distance').value):
            # Stop on immediate obstacle; Ackermann car cannot pivot in place -> back up after blocked_wait.
            self.state = 'BLOCKED_STOP'
            self.command(0, 0)
            now = self.get_clock().now()
            if self.blocked_since is None:
                self.blocked_since = now
            elif (bool(self.get_parameter('reverse_enable').value)
                  and (now - self.blocked_since).nanoseconds / 1e9 >= float(self.get_parameter('blocked_wait').value)):
                if self.rear_ok():
                    goal_side = left if desired > 0 else right
                    turn_left = (desired > 0) if goal_side > float(self.get_parameter('side_clearance').value) else left >= right
                    # Reversing flips the yaw-rate sign: steer right while backing up to swing the nose left.
                    self.reverse_steer = -limit if turn_left else limit
                    self.reverse_start = (x, y)
                    self.blocked_since = None
                    self.get_logger().info('Blocked: reversing to turn %s' % ('left' if turn_left else 'right'))
            return
        self.blocked_since = None
        if not self.trail or math.hypot(x - self.trail[-1][0], y - self.trail[-1][1]) > 0.05:
            self.trail = (self.trail + [(x, y)])[-200:]      # forward path (for reversing without a rear view)
        if front < float(self.get_parameter('clearance').value):
            self.state = 'AVOID'
            steer = limit if left >= right else -limit
            speed = min(speed, 0.18)
        elif left < float(self.get_parameter('side_clearance').value):
            self.state = 'SIDE_AVOID'
            steer = -limit * 0.6
            speed = min(speed, 0.2)
        elif right < float(self.get_parameter('side_clearance').value):
            self.state = 'SIDE_AVOID'
            steer = limit * 0.6
            speed = min(speed, 0.2)
        else:
            self.state = 'TRACK'
        self.command(speed, steer)


def main():
    rclpy.init()
    node = RoverNavigation()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.command(0, 0)
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
