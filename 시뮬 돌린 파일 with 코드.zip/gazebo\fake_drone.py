"""Stage-1 stand-in for the drone: sends rover_link cone_goal messages like follow_rover_v2 does.

Reads the rover's true pose from Gazebo (/odom is exact in Gazebo) and the cone's true position,
adds the errors seen in PX4 SITL (cone ~0.15 m per message + fixed per-run bias ~0.1 m,
rover ~0.05 m), and sends rover->cone in north/east at 5 Hz with age 0.3 s, same packet format
as rover_link.RoverLink. Starts after --t-detect seconds (drone still searching).
Also counts rover_odom packets coming back on UDP 47002.

  python3 fake_drone.py --cone-n 3 --cone-e 15
"""
import argparse
import json
import socket
import time
from collections import deque

import numpy as np
import rclpy
from nav_msgs.msg import Odometry
from rclpy.node import Node


class FakeDrone(Node):
    def __init__(self, a):
        super().__init__("fake_drone")
        self.a, self.rng = a, np.random.default_rng(a.seed)
        self.bias = self.rng.normal(0, 0.10, 2)
        self.hist = deque(maxlen=400)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.seq, self.t0 = 0, time.time()
        self.odom_in = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.odom_in.bind(("0.0.0.0", a.odom_port))
        self.odom_in.setblocking(False)
        self.n_odom = 0
        self.create_subscription(Odometry, "/odom", self.on_odom, 10)
        self.create_timer(0.2, self.tick)

    def on_odom(self, m):
        # world x = east, y = north (rover spawned at origin, yaw 0 -> odom == world)
        self.hist.append((time.time(), m.pose.pose.position.y, m.pose.pose.position.x))

    def tick(self):
        try:
            while True:
                self.odom_in.recvfrom(1024)
                self.n_odom += 1
        except BlockingIOError:
            pass
        if time.time() - self.t0 < self.a.t_detect or not self.hist:
            return
        h = np.array(self.hist)
        i = int(np.argmin(np.abs(h[:, 0] - (time.time() - 0.3))))
        rover = h[i, 1:] + self.rng.normal(0, 0.05, 2)
        cone = np.array([self.a.cone_n, self.a.cone_e]) + self.bias + self.rng.normal(0, 0.15, 2)
        rel = cone - rover
        msg = {"type": "cone_goal", "seq": self.seq, "age": 0.3, "rel_n": round(float(rel[0]), 3),
               "rel_e": round(float(rel[1]), 3), "dist": round(float(np.hypot(*rel)), 3),
               "same_instant": True, "n_cone": 10}
        self.sock.sendto(json.dumps(msg).encode(), (self.a.host, self.a.port))
        self.seq += 1
        if self.seq % 25 == 0:
            self.get_logger().info("sent %d cone_goal, got %d rover_odom" % (self.seq, self.n_odom))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cone-n", type=float, required=True)
    ap.add_argument("--cone-e", type=float, required=True)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=47000)
    ap.add_argument("--odom-port", type=int, default=47002)
    ap.add_argument("--t-detect", type=float, default=3.0)
    ap.add_argument("--seed", type=int, default=0)
    a, _ = ap.parse_known_args()
    rclpy.init()
    n = FakeDrone(a)
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
