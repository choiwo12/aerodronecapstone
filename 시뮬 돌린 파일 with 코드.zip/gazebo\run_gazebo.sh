#!/bin/bash
# Stage 1 closed loop in Gazebo (headless): rover + lidar + cone + obstacles, fake drone over UDP.
#   bash gazebo/run_gazebo.sh                     # 150 s run -> gazebo/out/
#   DUR=200 CONE_N=3 CONE_E=15 bash gazebo/run_gazebo.sh
#   VIDEO=1 bash gazebo/run_gazebo.sh             # also records $OUT/run.mp4 (top view | near the cone)
source /opt/ros/jazzy/setup.bash
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=${OUT:-$ROOT/gazebo/out}; DUR=${DUR:-150}; CONE_N=${CONE_N:-3}; CONE_E=${CONE_E:-20}; SEED=${SEED:-0}
VIDEO=${VIDEO:-0}
mkdir -p "$OUT"
export GZ_SIM_RESOURCE_PATH="$ROOT/gazebo/models:${GZ_SIM_RESOURCE_PATH:-}"   # model://cone_textures
pids=()
gz sim -s -r --headless-rendering "${WORLD:-$ROOT/gazebo/worlds/cone_field.sdf}" > "$OUT/gz.log" 2>&1 & pids+=($!)
ros2 run ros_gz_bridge parameter_bridge --ros-args -p config_file:="$ROOT/gazebo/config/bridge.yaml" > "$OUT/bridge.log" 2>&1 & pids+=($!)
if [ "${S500:-0}" = 1 ]; then      # S500 rig (A8 gimbal camera) driven by the PX4 SITL demo (--s500-gimbal)
  sleep 3
  gz service -s /world/cone_field/create --reqtype gz.msgs.EntityFactory --reptype gz.msgs.Boolean --timeout 5000     --req "sdf_filename: \"$ROOT/gazebo/models/s500_sensor_rig/model.sdf\", name: \"s500\", pose: {position: {x: 0, y: -1, z: 0.25}}"     > "$OUT/spawn_s500.log" 2>&1
  ros2 run ros_gz_bridge parameter_bridge /s500/a8/image@sensor_msgs/msg/Image[gz.msgs.Image     /s500/a8/yaw_cmd@std_msgs/msg/Float64]gz.msgs.Double /s500/a8/pitch_cmd@std_msgs/msg/Float64]gz.msgs.Double     /s500/a8/roll_cmd@std_msgs/msg/Float64]gz.msgs.Double /world/cone_field/set_pose@ros_gz_interfaces/srv/SetEntityPose     /s500/joint_state@sensor_msgs/msg/JointState[gz.msgs.Model /s500/down/image@sensor_msgs/msg/Image[gz.msgs.Image > "$OUT/bridge_s500.log" 2>&1 & pids+=($!)
fi
if [ "$VIDEO" = 1 ]; then
  sleep 3
  gz service -s /world/cone_field/create --reqtype gz.msgs.EntityFactory --reptype gz.msgs.Boolean \
    --timeout 5000 --req "sdf_filename: \"$ROOT/gazebo/models/video_cameras.sdf\"" > "$OUT/spawn.log" 2>&1
  ros2 run ros_gz_bridge parameter_bridge /cam/top@sensor_msgs/msg/Image[gz.msgs.Image \
    /cam/side@sensor_msgs/msg/Image[gz.msgs.Image > "$OUT/bridge_cam.log" 2>&1 & pids+=($!)
  python3 "$ROOT/gazebo/record_video.py" --out "$OUT/run_raw.mp4" --cone-n "$CONE_N" --cone-e "$CONE_E" > "$OUT/video.log" 2>&1 &
  rec=$!
fi
sleep 5
python3 "$ROOT/rover/rover_navigation.py" --ros-args -p rear_check:=false > "$OUT/nav.log" 2>&1 & pids+=($!)   # front-mounted lidar
python3 "$ROOT/rover/ros2/cone_mission_node.py" --ros-args -p north_yaw:=1.5708 -p log_file:="$OUT/mission.jsonl" > "$OUT/mission.log" 2>&1 & pids+=($!)
if [ "${DRONE:-fake}" = px4 ]; then      # real drone code runs in the PX4 SITL demo (gazebo/run_full_A.sh)
  python3 "$ROOT/gazebo/rover_truth_relay.py" > "$OUT/relay.log" 2>&1 & pids+=($!)
else
  python3 "$ROOT/gazebo/fake_drone.py" --cone-n "$CONE_N" --cone-e "$CONE_E" --seed "$SEED" > "$OUT/drone.log" 2>&1 & pids+=($!)
fi
trap 'kill ${pids[@]} 2>/dev/null; pkill -f "gz sim" 2>/dev/null' EXIT
for _ in $(seq "$DUR"); do [ -f "$OUT/stop" ] && break; sleep 1; done   # touch $OUT/stop to end early
if [ "$VIDEO" = 1 ]; then
  # recorder sometimes never exits after SIGINT (auto21: hung 2+ h) -> give it 30 s, then SIGKILL
  kill -INT $rec
  for _ in $(seq 30); do kill -0 $rec 2>/dev/null || break; sleep 1; done
  kill -9 $rec 2>/dev/null; wait $rec 2>/dev/null
  ffmpeg -y -loglevel error -i "$OUT/run_raw.mp4" -c:v libx264 -pix_fmt yuv420p -crf 23 "$OUT/run.mp4" && rm "$OUT/run_raw.mp4"
fi
echo "done: $OUT"
