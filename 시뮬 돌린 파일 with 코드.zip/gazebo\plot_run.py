"""Plot a Gazebo run (mission.jsonl from cone_mission_node) and print the final metrics.

  python gazebo/plot_run.py gazebo/out/run1        # -> run1/run.png, run1/run_zoom.png, run1/metrics.json
World layout must match gazebo/worlds/cone_field.sdf (read from it).
"""
import json
import math
import os
import re
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "sim"))
sys.path.insert(0, os.path.join(ROOT, "rover"))
from cone_mission.geometry import side_gap  # noqa: E402
from offline_sim import ROVER_L, ROVER_W, clearance  # noqa: E402


def world_shapes(sdf_path):
    """cone (x, y) and obstacles ('b', x0, x1, y0, y1) / ('c', x, y, r) from the static models."""
    txt = open(sdf_path, encoding="utf-8").read()
    cone, shapes = None, []
    for name, body in re.findall(r'<model name="(\w+)">(.*?)</model>', txt, re.S):
        if name in ("ground", "rover"):
            continue
        px, py, pz = map(float, re.search(r"<pose>([-\d.]+) ([-\d.]+) ([-\d.]+)", body).groups())
        if name == "cone":
            cone = (px, py); continue
        col = re.search(r'<collision name="c">(.*?)</collision>', body, re.S).group(1)
        b = re.search(r"<box><size>([-\d.]+) ([-\d.]+) ([-\d.]+)", col)
        hz = float(b.group(3)) / 2 if b else float(re.search(r"<length>([-\d.]+)", col).group(1)) / 2
        if pz - hz > 0.5:                         # overhead (canopy roof): rover drives under it
            continue
        if b:
            sx, sy = float(b.group(1)), float(b.group(2))
            shapes.append(("b", px - sx / 2, px + sx / 2, py - sy / 2, py + sy / 2))
        else:
            r = float(re.search(r"<radius>([-\d.]+)", col).group(1))
            shapes.append(("c", px, py, r))
    return cone, shapes


def main():
    run = sys.argv[1]
    rows = [json.loads(line) for line in open(os.path.join(run, "mission.jsonl"))]
    w = os.path.join(run, "world.sdf")                 # per-run copy (run_full_A.sh), else the repo world
    cone, shapes = world_shapes(w if os.path.exists(w) else os.path.join(ROOT, "gazebo", "worlds", "cone_field.sdf"))
    t0 = rows[0]["t"]
    tr = np.array([r["pose"] for r in rows])
    st = [r["state"] for r in rows]
    t_cone = next((r["t"] - t0 for r in rows if r["cone"] is not None), None)
    t_arr = next((r["t"] - t0 for r in rows if r["state"] == "ARRIVED"), None)
    gap, along = side_gap(tr[-1], cone)
    min_clear = min(clearance(p[0], p[1], p[2], shapes) for p in tr)
    est = rows[-1]["cone"]
    m = {"cone_seen_s": round(t_cone, 1), "arrived_s": None if t_arr is None else round(t_arr, 1),
         "drive_s": None if t_arr is None else round(t_arr - t_cone, 1),
         "gap_m": round(gap, 3), "along_m": round(along, 3),
         "cone_estimate_error_m": round(math.dist(est, cone), 3),
         "min_obstacle_clearance_m": round(min_clear, 3), "final_state": st[-1]}
    json.dump(m, open(os.path.join(run, "metrics.json"), "w"), indent=1)
    print(json.dumps(m))

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle, Polygon, Rectangle
    fig, ax = plt.subplots(figsize=(8, 6))
    for s in shapes:
        if s[0] == "c":
            ax.add_patch(Circle((s[1], s[2]), s[3], color="0.55"))
        else:
            ax.add_patch(Rectangle((s[1], s[3]), s[2] - s[1], s[4] - s[3], color="0.55"))
    ax.add_patch(Circle(cone, 0.19, color="#f07000", zorder=5, label="cone (true)"))
    ax.plot(*est, "x", color="k", ms=8, label="cone (from drone)")
    ax.plot(tr[:, 0], tr[:, 1], color="#3060c0", lw=1.5, label="rover (Gazebo)")
    wps = np.array(rows[-1]["wps"])
    ax.plot(wps[:, 0], wps[:, 1], "o--", color="0.3", ms=4, lw=0.8, label="last waypoints")
    x, y, th = tr[-1]
    c, s_ = math.cos(th), math.sin(th)
    corners = [(ROVER_L / 2, ROVER_W / 2), (-ROVER_L / 2, ROVER_W / 2), (-ROVER_L / 2, -ROVER_W / 2), (ROVER_L / 2, -ROVER_W / 2)]
    ax.add_patch(Polygon([(x + c * u - s_ * v, y + s_ * u + c * v) for u, v in corners], fc="#3060c0", ec="k", alpha=0.8, zorder=6))
    ax.set_aspect("equal"); ax.grid(alpha=0.3); ax.legend(fontsize=8, loc="upper left")
    ax.set_xlabel("east [m]"); ax.set_ylabel("north [m]")
    ax.set_title(f"Gazebo: gap {gap:.2f} m (target 0.30), drive {m['drive_s']} s, "
                 f"min clearance {min_clear:.2f} m", fontsize=9)
    fig.savefig(os.path.join(run, "run.png"), dpi=110, bbox_inches="tight")
    ax.set_xlim(cone[0] - 2, cone[0] + 2); ax.set_ylim(cone[1] - 2, cone[1] + 2)
    fig.savefig(os.path.join(run, "run_zoom.png"), dpi=110, bbox_inches="tight")


if __name__ == "__main__":
    main()
