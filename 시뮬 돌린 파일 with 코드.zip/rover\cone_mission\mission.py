"""Rover-side cone mission logic (no ROS): cone position -> RRT* path -> waypoints for rover_navigation.

rover_navigation.py takes one /goal_relative at a time and freezes it in odom. This class decides
which waypoint to hand over next and which navigation parameters to use.

States
  WAIT_CONE  no cone position from the drone yet (rover_navigation has no goal -> stands still)
  GO         following RRT* waypoints towards the lead-in point
  FINAL      last 3 m along a straight line to the stop point (carrot 1 m ahead on the line); side/front thresholds lowered so the
             cone 0.3 m to the right does not trigger avoidance
  ARRIVED    within final arrival radius of the stop point
"""
import math

import numpy as np

from .geometry import approach, refine_cone, stop_point, to_rover_frame
from .planner import inside, plan, segment_free

NORMAL = {"side_clearance": 0.75, "clearance": 1.8, "stop_distance": 1.2, "arrival_radius": 0.35}
FINAL = {"side_clearance": 0.40, "clearance": 1.0, "stop_distance": 0.5, "arrival_radius": 0.20}


class ConeMission:
    def __init__(self, lead=3.0, lookahead=1.0, switch_radius=0.8, replan_shift=1.0, retarget_shift=0.2,
                 final_shift=0.15, check_period=2.0, seed=0, lidar_range=5.0):
        self.lead, self.lookahead, self.switch_radius = lead, lookahead, switch_radius
        self.carrot = None          # last goal sent on the final approach line
        self.lidar_range = lidar_range   # within this distance the rover lidar refines the cone
        self.lidar_lock = False
        self.cone_used = None
        # 마지막으로 라이다가 잡은 라바콘 위치. 바로 옆까지 가면 라이다 점이 잠깐 빠져 보정이 풀리는데, 그때 드론 추정값
        # (0.5~0.7 m 오차)으로 돌아가면 정지점이 튀어 로버가 라바콘 쪽으로 꺾임 (Gazebo 반복 시험 3회차: 옆 간격 −0.02 m)
        # → 라바콘은 안 움직이므로 lock_hold 초 안에는 마지막 라이다 위치를 계속 씀
        self.lock_cone, self.t_lock, self.lock_hold = None, None, 5.0
        self.arrived_locked = False
        # 진행 감시: GO/FINAL 에서 stuck_time 초 동안 0.2 m 도 못 가면 장애물 여유를 extra_step 만큼 넓혀 다시 계획
        self.stuck_time, self.extra_step, self.extra_max = 8.0, 0.2, 0.6
        self.extra = 0.0
        self._prog = None
        self.n_stuck = 0
        # 드론 라바콘 추정은 0.5 m 쯤 흔들림. 예전엔 0.4 m 만 바뀌어도 RRT* 를 처음부터 다시 돌려(무작위) 기둥을 지나는 쪽이
        # 1~2 s 마다 남↔북으로 바뀌었고, 로버가 그 사이 기둥 정면에 걸림 (Gazebo cmp3_mrcnn run3, 기둥3 앞 후진 5회).
        # → retarget_shift~replan_shift 사이면 지금 경로의 앞부분은 두고 끝(진입점·정지점)만 옮김(_retarget),
        #   replan_shift 넘게 바뀌거나 옮긴 경로가 막힐 때만 전체 재계획
        self.replan_shift, self.retarget_shift = replan_shift, retarget_shift
        self.final_shift, self.check_period = final_shift, check_period
        self.n_retarget = 0
        self.seed = seed
        self.state = "WAIT_CONE"
        self.cone = None            # cone used for the current plan (odom)
        self.heading = None
        self.waypoints = []         # odom points; last one is the stop point
        self.idx = 0
        self.t_check = 0.0
        self.n_plans = 0
        self.params = dict(NORMAL)

    # ---------------------------------------------------------------- helpers
    def _free_fn(self, circles, cone):
        near_cone = [c for c in circles if math.hypot(c[0] - cone[0], c[1] - cone[1]) < 0.45]
        others = [c for c in circles if c not in near_cone]

        def free(p, s):
            return (not inside(p, circles) and not inside(s, others)
                    and segment_free(p, s, others))
        return free

    def _replan(self, xy, cone, circles):
        p, s, h = approach(cone, xy, self.lead, free=self._free_fn(circles, cone))
        path = plan(xy, p, circles, seed=self.seed + self.n_plans)
        self.n_plans += 1
        self.cone, self.heading = np.array(cone, float), h
        self.waypoints = (path[1:] if path else [tuple(p)]) + [tuple(s)]
        self.idx = 0
        self.carrot = None
        self.state = "GO" if len(self.waypoints) > 1 else "FINAL"
        self.plan_ok = path is not None

    def _retarget(self, xy, cone, circles):
        """Keep the current path, move only its end (lead-in + stop point) to the new cone. False if that is blocked."""
        p, s, h = approach(cone, xy, self.lead, free=self._free_fn(circles, cone))
        obs = [c for c in circles if not inside(xy, [c])]
        mid = self.waypoints[self.idx:-2]                    # waypoints still ahead, before the old lead-in point
        pts = [tuple(xy)] + mid + [tuple(p)]
        if any(not segment_free(a, b, obs) for a, b in zip(pts[:-1], pts[1:])):
            return False
        self.waypoints = self.waypoints[:self.idx] + mid + [tuple(p), tuple(s)]
        self.cone, self.heading = np.array(cone, float), h
        self.n_retarget += 1
        return True

    def _send(self, pose, actions):
        target = self.waypoints[self.idx]
        actions.append(("goal", to_rover_frame(pose, target)))

    def _set_params(self, p, actions):
        if p != self.params:
            self.params = dict(p)
            actions.append(("params", dict(p)))

    # ---------------------------------------------------------------- main
    def step(self, t, pose, cone, circles, scan_pts=None):
        """pose=(x, y, yaw) odom; cone=(x, y) odom or None (from the drone); circles=[(x, y, r)];
        scan_pts = latest lidar hits in odom (N, 2), used to refine the cone when close.
        Returns list of actions: ('goal', (forward, left)) and/or ('params', dict)."""
        actions = []
        xy = np.array(pose[:2], float)
        if cone is None:
            return actions
        cone = np.asarray(cone, float)
        if self.extra > 0:
            circles = [(cx, cy, r + self.extra) for cx, cy, r in circles]
        if self.state in ("GO", "FINAL"):
            if self._prog is None or np.hypot(*(xy - self._prog[1])) > 0.2:
                self._prog = (t, xy.copy())
            elif t - self._prog[0] > self.stuck_time:
                self.extra = min(self.extra + self.extra_step, self.extra_max)
                self.n_stuck += 1
                circles = [(cx, cy, r + self.extra_step) for cx, cy, r in circles]
                self._prog = (t, xy.copy())
                self._replan(xy, cone, circles); self._set_params(NORMAL if self.state == "GO" else FINAL, actions)
                self._send(pose, actions)
                return actions
        else:
            self._prog = None
        self.lidar_lock = False
        if scan_pts is not None and np.hypot(*(cone - xy)) < self.lidar_range:
            refined, self.lidar_lock = refine_cone(cone, scan_pts, xy)
            if self.lidar_lock:
                self.lock_cone, self.t_lock = refined, t
                cone = refined
            elif (self.lock_cone is not None and t - self.t_lock < self.lock_hold
                  and np.hypot(*(cone - self.lock_cone)) < 1.5):
                cone = self.lock_cone
        self.cone_used = cone

        if self.state == "WAIT_CONE":
            self._replan(xy, cone, circles); self.t_check = t
            self._set_params(FINAL if self.state == "FINAL" else NORMAL, actions)
            self._send(pose, actions)
            return actions

        if self.state == "ARRIVED":
            # 도착 순간 라이다가 라바콘을 잡고 있었으면 그 위치를 믿음: 앞 범퍼 라이다는 정지 후 옆·뒤의 라바콘을 못 봐서
            # 5 s 뒤 드론 추정값(0.5 m 오차)으로 돌아가는데, 그걸로 다시 출발하면 안 됨 (Gazebo 10회 시험 4회차)
            if np.hypot(*(cone - self.cone)) > (2.0 if self.arrived_locked else 0.5):   # cone moved a lot -> go again
                self._replan(xy, cone, circles); self._set_params(NORMAL, actions); self._send(pose, actions)
            return actions

        if self.state == "GO":
            shift = np.hypot(*(cone - self.cone))
            if shift > self.retarget_shift:
                before = self.waypoints[self.idx]
                if shift > self.replan_shift or not self._retarget(xy, cone, circles):
                    self._replan(xy, cone, circles); self.t_check = t
                if self.waypoints[self.idx] != before:      # same target -> no new goal for rover_navigation
                    self._send(pose, actions)
                return actions
            if t - self.t_check > self.check_period:
                self.t_check = t
                obs = [c for c in circles if not inside(xy, [c])]
                pts = [tuple(xy)] + self.waypoints[self.idx:-1]
                if any(not segment_free(a, b, obs) for a, b in zip(pts[:-1], pts[1:])):
                    self._replan(xy, cone, circles); self._send(pose, actions)
                    return actions
            if np.hypot(*(xy - self.waypoints[self.idx])) < self.switch_radius:
                self.idx += 1
                if self.idx == len(self.waypoints) - 1:
                    self.state = "FINAL"
                    self._set_params(FINAL, actions)
                self._send(pose, actions)
            return actions

        # FINAL: follow the straight approach line (carrot `lookahead` m ahead on the line, clipped at the stop
        # point) so the rover ends parallel to the planned heading, not at whatever angle it came in.
        s = stop_point(cone, self.heading)
        if np.hypot(*(s - np.array(self.waypoints[-1]))) > 0.5:
            # 정지점이 크게 옮겨짐(늦게 라이다가 라바콘을 잡음 등) → 급하게 꺾지 말고 접근을 다시 계획
            # (Gazebo 반복 시험 2회차: 1.1 m 앞에서 정지점이 1.2 m 튀어 57° 꺾인 채 정지, 옆 간격 0.13 m)
            self._replan(xy, cone, circles); self._set_params(NORMAL if self.state == "GO" else FINAL, actions)
            self._send(pose, actions)
            return actions
        if np.hypot(*(s - np.array(self.waypoints[-1]))) > (0.05 if self.lidar_lock else self.final_shift):
            self.waypoints[-1] = tuple(s); self.cone = cone
        u = np.array([math.cos(self.heading), math.sin(self.heading)])
        S = np.array(self.waypoints[-1])
        along = (xy - S) @ u
        carrot = S + min(along + self.lookahead, 0.0) * u
        if self.carrot is None or np.hypot(*(carrot - self.carrot)) > 0.15 or (along + self.lookahead >= 0
                                                                              and np.hypot(*(carrot - self.carrot)) > 0.02):
            self.carrot = carrot
            actions.append(("goal", to_rover_frame(pose, carrot)))
        d = np.hypot(*(xy - S))
        if d < FINAL["arrival_radius"] + 0.05:
            self.state = "ARRIVED"
            self.extra = 0.0
            self.arrived_locked = self.t_lock is not None and t - self.t_lock < self.lock_hold
            self._set_params(NORMAL, actions)
        elif along > 0.6:                                    # drove past the stop point -> new approach
            self._replan(xy, cone, circles); self._set_params(NORMAL if self.state == "GO" else FINAL, actions)
            self._send(pose, actions)
        return actions
