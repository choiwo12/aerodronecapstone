"""Record the Gazebo run: top view | oblique view side by side, with mission state overlay -> mp4.

Frames are written as camera images arrive (sim time), so the video plays at sim speed.

  python3 record_video.py --out run.mp4 --cone-e 15 --cone-n 3
"""
import argparse
import math
import time

import cv2
import numpy as np
import rclpy
from rclpy.executors import ExternalShutdownException
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String


def to_bgr(m):
    a = np.frombuffer(m.data, np.uint8).reshape(m.height, m.step)[:, :m.width * 3].reshape(m.height, m.width, 3)
    return cv2.cvtColor(a, cv2.COLOR_RGB2BGR) if m.encoding == "rgb8" else a.copy()


class Recorder(Node):
    def __init__(self, a):
        super().__init__("video_recorder")
        self.a, self.side, self.state, self.pose, self.t0 = a, None, "-", None, None
        self.writer, self.n = None, 0
        self.create_subscription(Image, "/cam/top", self.on_top, 5)
        self.create_subscription(Image, "/cam/side", self.on_side, 5)
        self.create_subscription(String, "/mission/state", lambda m: setattr(self, "state", m.data), 5)
        self.create_subscription(Odometry, "/odom", self.on_odom, 5)

    def on_odom(self, m):
        q = m.pose.pose.orientation
        self.pose = (m.pose.pose.position.x, m.pose.pose.position.y,
                     math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z)))

    def on_side(self, m):
        self.side = to_bgr(m)

    def on_top(self, m):
        top = to_bgr(m)
        side = self.side if self.side is not None else np.zeros_like(top)
        t = m.header.stamp.sec + m.header.stamp.nanosec * 1e-9
        self.t0 = t if self.t0 is None else self.t0
        frame = np.hstack([top, side])
        lines = [f"t = {t - self.t0:5.1f} s   mission: {self.state}"]
        if self.pose is not None:
            x, y, th = self.pose
            dx, dy = self.a.cone_e - x, self.a.cone_n - y
            fwd, left = math.cos(th) * dx + math.sin(th) * dy, -math.sin(th) * dx + math.cos(th) * dy
            gap = -left - 0.19 - 0.21
            lines.append(f"rover ({x:5.2f}, {y:5.2f})   cone-rover centre {math.hypot(dx, dy):5.2f} m"
                         + (f"   side gap {gap:4.2f} m (target 0.30)" if abs(fwd) < 0.6 and left < 0 else ""))
        for i, s in enumerate(lines):
            cv2.putText(frame, s, (10, 22 + 20 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 3, cv2.LINE_AA)
            cv2.putText(frame, s, (10, 22 + 20 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(frame, "top view (north up)", (12, frame.shape[0] - 14), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        cv2.putText(frame, "near the cone", (top.shape[1] + 12, frame.shape[0] - 14), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        if self.writer is None:
            self.writer = cv2.VideoWriter(self.a.out, cv2.VideoWriter_fourcc(*"mp4v"), self.a.fps, (frame.shape[1], frame.shape[0]))
            self.get_logger().info("first frame wall time %.3f" % time.time())
        self.writer.write(frame)
        self.n += 1
        if self.n % 100 == 0:
            self.get_logger().info(f"{self.n} frames")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--cone-n", type=float, default=3.0)
    ap.add_argument("--cone-e", type=float, default=15.0)
    ap.add_argument("--fps", type=float, default=5.0, help="= camera update_rate in models/video_cameras.sdf")
    a, _ = ap.parse_known_args()
    rclpy.init()
    r = Recorder(a)
    try:
        rclpy.spin(r)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if r.writer is not None:
            r.writer.release()
        r.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
